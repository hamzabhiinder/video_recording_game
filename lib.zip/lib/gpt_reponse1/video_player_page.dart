import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'score_provider.dart';
import 'package:provider/provider.dart';

class VideoPlayerPage extends StatefulWidget {
  final String filePath;

  const VideoPlayerPage({Key? key, required this.filePath}) : super(key: key);

  @override
  _VideoPlayerPageState createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(File(widget.filePath))
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Video Playback'),
      ),
      body: Stack(
        children: [
          VideoPlayer(_controller),
          Consumer<ScoreProvider>(
            builder: (context, scoreProvider, child) {
              return ListView.builder(
                itemCount: scoreProvider.scores.length,
                itemBuilder: (context, index) {
                  final score = scoreProvider.scores[index];
                  return Positioned(
                    top: (index + 1) * 20.0,
                    right: 20.0,
                    child: Text('${score.description} (${score.score})'),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
