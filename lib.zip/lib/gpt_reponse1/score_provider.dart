import 'dart:developer';

import 'package:flutter/material.dart';

class Score {
  final int score;
  final String description;
  final DateTime timestamp;

  Score({required this.score, required this.description, required this.timestamp});
}

class ScoreProvider extends ChangeNotifier {
  List<Score> _scores = [];

  List<Score> get scores => _scores;

  void addScore(int score, String description) {
    _scores.add(Score(score: score, description: description, timestamp: DateTime.now()));
    log('message ${_scores.toList()}');
    notifyListeners();
  }
}
