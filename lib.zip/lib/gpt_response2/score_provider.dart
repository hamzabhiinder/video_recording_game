import 'package:flutter/material.dart';

import 'video_player_page.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Match Recording App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => VideoPlaybackScreen(videoUrl: 'your_video_url_here')),
                );
              },
              child: Text('Play Recorded Video'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RecordingScreen()),
                );
              },
              child: Text('Start Recording'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MatchDetailsScreen()),
                );
              },
              child: Text('Match Details'),
            ),
          ],
        ),
      ),
    );
  }
}
class Match {
  final int matchID;
  final String redOpp;
  final String greenOpp;
  final String redSchool;
  final String greenSchool;
  final int weightClass;

  Match({
    required this.matchID,
    required this.redOpp,
    required this.greenOpp,
    required this.redSchool,
    required this.greenSchool,
    required this.weightClass,
  });
}

class MatchScore {
  final int matchScoreID;
  final int matchID;
  final String time;
  final int period;
  final int scoreID;
  final String scorer;

  MatchScore({
    required this.matchScoreID,
    required this.matchID,
    required this.time,
    required this.period,
    required this.scoreID,
    required this.scorer,
  });
}

class MatchResult {
  final int matchResultID;
  final int matchID;
  final String result;
  final String time;
  final int redOpp;
  final int greenOpp;
  final int period;

  MatchResult({
    required this.matchResultID,
    required this.matchID,
    required this.result,
    required this.time,
    required this.redOpp,
    required this.greenOpp,
    required this.period,
  });
}

class MatchChoice {
  final int matchChoiceID;
  final int matchID;
  final int choiceID;
  final int period;

  MatchChoice({
    required this.matchChoiceID,
    required this.matchID,
    required this.choiceID,
    required this.period,
  });
}

class Choice {
  final int choiceID;
  final String choice;
  final String description;

  Choice({
    required this.choiceID,
    required this.choice,
    required this.description,
  });
}

class Score {
  final int scoreID;
  final String score;
  final String description;
  final int points;

  Score({
    required this.scoreID,
    required this.score,
    required this.description,
    required this.points,
  });
}
