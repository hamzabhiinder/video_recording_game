import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoPlaybackScreen extends StatefulWidget {
  final String videoUrl;
  VideoPlaybackScreen({required this.videoUrl});

  @override
  _VideoPlaybackScreenState createState() => _VideoPlaybackScreenState();
}

class _VideoPlaybackScreenState extends State<VideoPlaybackScreen> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(widget.videoUrl)
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Video Playback')),
      body: Stack(
        children: [
          Center(
            child: _controller.value.isInitialized
                ? AspectRatio(
                    aspectRatio: _controller.value.aspectRatio,
                    child: VideoPlayer(_controller),
                  )
                : CircularProgressIndicator(),
          ),
          // Overlay match details here using Positioned widgets
          Positioned(
            top: 20,
            left: 20,
            child: Container(
              padding: EdgeInsets.all(8),
              color: Colors.black54,
              child: Text(
                'Match Details',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          // Add more Positioned widgets for displaying scores, names, etc.
        ],
      ),
    );
  }
}


class RecordingScreen extends StatefulWidget {
  @override
  _RecordingScreenState createState() => _RecordingScreenState();
}

class _RecordingScreenState extends State<RecordingScreen> {
  bool _isRecording = false;

  void _toggleRecording() {
    setState(() {
      _isRecording = !_isRecording;
    });
    // Implement your recording logic here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recording Screen')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _toggleRecording,
              child: Text(_isRecording ? 'Stop Recording' : 'Start Recording'),
            ),
          ],
        ),
      ),
    );
  }
}

class MatchDetailsScreen extends StatefulWidget {
  @override
  _MatchDetailsScreenState createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  // Example data (replace with actual data retrieval)
  int _period = 1;
  int _redScore = 0;
  int _greenScore = 0;
  List<String> _periods = ['1', '2', '3', '4', '5', '6', '7', '8'];
  List<String> _scoreButtons = ['T3', 'E1', 'R2', 'N2', 'N3', 'N4', 'N5', 'P1', 'P2', 'C0', 'S0', 'V1'];

  void _changePeriod(int newPeriod) {
    setState(() {
      _period = newPeriod;
    });
    // Implement logic to update UI based on new period
  }

  void _updateScore(String scoreType) {
    // Example logic to update scores
    setState(() {
      if (scoreType.startsWith('R')) {
        _redScore += 3; // Replace with actual score logic
      } else if (scoreType.startsWith('G')) {
        _greenScore += 3; // Replace with actual score logic
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Match Details')),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              DropdownButton<String>(
                value: _period.toString(),
                onChanged: (value) => _changePeriod(int.parse(value!)),
                items: _periods.map((period) {
                  return DropdownMenuItem<String>(
                    value: period,
                    child: Text('Period $period'),
                  );
                }).toList(),
              ),
              Text('Red Score: $_redScore'),
              Text('Green Score: $_greenScore'),
            ],
          ),
          GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2,
            ),
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: _scoreButtons.length,
            itemBuilder: (context, index) {
              return ElevatedButton(
                onPressed: () => _updateScore(_scoreButtons[index]),
                child: Text(_scoreButtons[index]),
              );
            },
          ),
        ],
      ),
    );
  }
}
