import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'score_provider.dart';
import 'video_player_page.dart';

class ResultScreen extends StatelessWidget {
  final String videoPath;

  const ResultScreen({Key? key, required this.videoPath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Game Result'),
      ),
      body: Consumer<ScoreProvider>(
        builder: (context, scoreProvider, child) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Player 1 Total Score: ${scoreProvider.totalScore1}',
                style: TextStyle(color: Colors.red, fontSize: 24),
              ),
              Text(
                'Player 2 Total Score: ${scoreProvider.totalScore2}',
                style: TextStyle(color: Colors.green, fontSize: 24),
              ),
              SizedBox(height: 20),
              DataTable(
                columns: [
                  DataColumn(label: Text('MatchScoreID')),
                  DataColumn(label: Text('MatchID')),
                  DataColumn(label: Text('Time')),
                  DataColumn(label: Text('Period')),
                  DataColumn(label: Text('ScoreID')),
                  DataColumn(label: Text('Scorer')),
                ],
                rows: scoreProvider.scores.map((score) {
                  return DataRow(cells: [
                    DataCell(Text(score.matchScoreID.toString())),
                    DataCell(Text(score.matchID.toString())),
                    DataCell(Text(score.time)),
                    DataCell(Text(score.period.toString())),
                    DataCell(Text(score.scoreID.toString())),
                    DataCell(Text(score.scorer)),
                  ]);
                }).toList(),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => VideoPlayerPage(filePath: videoPath),
                    ),
                  );
                },
                child: Text('Play Video'),
              ),
            ],
          );
        },
      ),
    );
  }
}
